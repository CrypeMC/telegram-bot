const TelegramBot = require('node-telegram-bot-api');
const express = require('express');

// Настройки
const BOT_TOKEN = '8180971200:AAGTXKVj8QjU9XtwEa-SUK2yXmZoef2SyKo'; // Замените на реальный токен
const CHAT_ID = '-4651349228';     // ID группы/чата для модерации (цифры, например -1001234567890)

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const app = express();
app.use(express.json());

// Проверка работы бота
bot.on('message', (msg) => {
  if (msg.text === '/start') {
    bot.sendMessage(msg.chat.id, '🚀 Бот для модерации отзывов запущен!');
  }
});

// Приём отзывов с сайта
app.post('/notify', (req, res) => {
  const { name, review } = req.body;
  bot.sendMessage(
    CHAT_ID,
    `📝 Новый отзыв:\n\nИмя: ${name}\nТекст: ${review}`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: '✅ Одобрить', callback_data: `approve_${name}|${review}` }],
          [{ text: '❌ Отклонить', callback_data: 'reject' }]
        ]
      }
    }
  );
  res.sendStatus(200);
});

// Обработка кнопок
bot.on('callback_query', (query) => {
  const chatId = query.message.chat.id;
  if (query.data === 'reject') {
    bot.deleteMessage(chatId, query.message.message_id);
  } else if (query.data.startsWith('approve_')) {
    const [name, review] = query.data.replace('approve_', '').split('|');
    bot.sendMessage(chatId, `👍 Одобрен отзыв от ${name}:\n\n${review}`);
    bot.deleteMessage(chatId, query.message.message_id);
  }
});

// Веб-сервер для Railway
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Сервер запущен на порту ${PORT}`));
